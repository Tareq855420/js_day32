@extends('master')

@section('title')
    Java Script
@endsection

@section('body')

    <h1 id="h1"></h1>
    <div id="content"></div>

    <script>

        function createDiv(height, width, color) {
            var div = document.createElement('div');
            div.style.height = height+'px';
            div.style.width = width+'px';
            div.style.backgroundColor = color+'';
            div.style.borderRadius = '100px';
            div.style.float = 'left';
            div.setAttribute('id', 'colorDiv');

            var content = document.getElementById('content');
            content.append(div);
        }

        createDiv(300, 400, 'red');
        createDiv(100, 200, 'green');
        createDiv(300, 150, 'gray');
        createDiv(300, 500, 'black');

        // function name() {
        //     // document.write('Tareq');
        //     alert('Hello World');
        // }
        //
        // name();

        // var firstName = 'Sawon';
        // var lastName = 'Akter';

        // function printName() {
        //     document.write(firstName+ ' ' +lastName);
        // }
        // printName();


        // getResult(10, 2);

        //
        function getResult(firstNumber, lastNumber) {
            document.write(firstNumber - lastNumber+'<br>');
        }
        //
        // getResult(100, 50);

        function getFullName(firstName, lastName) {
            var fullName = firstName+' '+lastName;
            // var h1 = document.getElementById('h1');
            // var h1 = document.getElementsByName(h1)[0];
            //
            // h1Element.innerHTML = fullName;

            document.getElementById('h1').innerHTML = fullName;
            // document.getElementsByTagName('h1')[0].innerHTML = fullName;
        }

        getFullName("Habibur", "Rahman");


        // var data = ['Shila', 'Sadia', 100, 10.25, 'bitm', 'Bangladesh', 200, 25.30];
        //
        // for (index in data)
        // {
        //     if (key > 1)
        //     {
        //         document.write(data[key]+'<br>')
        //     }
        //     // document.write(data[index]+'<br>');
        // }
        //
        //
        // var firstNumber = 'Sajjad';
        // var lastNumber = 'Hossain';
        //
        // document.write(firstNumber + ' &nbsp;&nbsp;&nbsp; ' + lastNumber);
        //
        //
        // document.write("Hello World");
        //
        // major rules for variable
        // * start with var
        // * a-z, A-Z, 0-9, $
        // * no number in first
        //
        // var name = 'Shanto';
        // var street = '22 street';
        // var Bangladesh = 'Hello Bangladesh';
        // var arif_name = 'His name is Arif';
        // var hellojenifer = "Hello Jenifer";
        //
        // var firstNumber = 10;
        // var bitm = 'bitm';
        // var price = 100.00;
        //
        // document.write(typeof(price));

    </script>

@endsection
